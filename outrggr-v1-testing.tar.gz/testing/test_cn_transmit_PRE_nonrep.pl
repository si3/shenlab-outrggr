use strict;
use warnings;
use List::MoreUtils qw|none all uniq|;
use Utils::File::Iter qw|iter_file slurp_file|;
use Getopt::Euclid;
use Genet::Ped;
use Genome::UCSC::BinKeeper;
use Data::Dumper;

my $ped = Genet::Ped->new($ARGV{'--ped'});
my %trios = $ped->get_trios();

my @fields = split(',', $ARGV{'--fields'});

my %keep = map { $_->{$fields[0]} => 1 } slurp_file($ARGV{'--cnv'}, { type => "csv" });

my %roles;
my %bk;
my $bkall = Genome::UCSC::BinKeeper->new();
while(my ($famid, $trios) = each %trios) {
	foreach my $trio (@$trios) {
		my ($iid, $dad, $mom) = @$trio;
		unless (all { defined $keep{$_} } @$trio) {
			warn "Skip incomplete trio ($iid, $dad, $mom)";
		}
		if (none { defined $roles{$_} } @$trio) {
			$roles{$iid} = ["Proband", $dad, $mom];
			$roles{$dad} = ["Father", $iid];
			$roles{$mom} = ["Mother", $iid];
			foreach (@$trio) {
				$bk{$_} = Genome::UCSC::BinKeeper->new();
			}
		}
		else {
			#die "Proband $iid and parents already found" if defined $roles{$iid};
			$roles{$iid} = ["Proband", $dad, $mom];
			$bk{$iid} = Genome::UCSC::BinKeeper->new();
			warn "Skip trio ($iid, $dad, $mom) for transmission analysis";
		}		
	}
}


my $it = iter_file($ARGV{'--cnv'}, { type => "csv" });
 
# Store CNVs in BinKeeper for each sample
while(my $dat = $it->()) {
	my ($iid, $chr, $start, $end, $cnv, $qual) = @{$dat}{@fields};
	unless (defined $bk{$iid}) {
        	print STDERR "$iid not in PED file\n"; next;
        }
	$bk{$iid}->add($chr, $start, $end, $cnv, $qual);
	$bkall->add($chr, $start, $end, $cnv, $qual, $iid);
}

# Now go through the CNV list again
$it = iter_file($ARGV{'--cnv'}, { type => "csv" });
open my $finh, ">$ARGV{'--output'}.inherit.txt" or die "Cannot write to inherit.txt";
print $finh join("\t", qw|IID Chrom Start End CN Qual Inherit|), "\n";
open my $ftrans, ">$ARGV{'--output'}.transmit.txt" or die "Cannot write to transmit.txt";
print $ftrans join("\t", qw|IID Chrom Start End CN Qual Role Transmit|), "\n";
while(my $dat = $it->()) {
	my ($iid, $chr, $start, $end, $cnv, $qual) = @{$dat}{@fields};
	next unless defined $roles{$iid} && $qual >= $ARGV{'--Q1'};

	# Filter to keep only rare CNVs	
	my @carriers = uniq sort map { $_->[4] } 
		grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
		$bkall->find_range($chr, $start, $end, 
			{ tCover => $ARGV{'--overlap'}, qCover => $ARGV{'--overlap'} });
	
	next unless @carriers <= $ARGV{'--maxfreq'};

	if ($roles{$iid}[0] eq 'Father' || $roles{$iid}[0] eq 'Mother') {
		my $child = $roles{$iid}[1];
		my @child_overlap = grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
			$bk{$child}->find_range($chr, $start, $end, 
			{ qCover => $ARGV{'--overlap'} });
		push @child_overlap => grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
			$bk{$child}->find_range($chr, $start, $end, 
			{ tCover => $ARGV{'--overlap'} });
		my $flag;
		if (@child_overlap > 0) {
			$flag = "Transmitted";
		}
		else {
			$flag = "NonTransmitted";
		}
		print $ftrans join("\t",  @{$dat}{@fields}, $roles{$iid}[0], $flag), "\n";
	}
	elsif ($roles{$iid}[0] eq 'Proband') {
		my ($dad, $mom) = ($roles{$iid}[1], $roles{$iid}[2]);
		my @dad_overlap = grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
			$bk{$dad}->find_range($chr, $start, $end, 
			{ qCover => $ARGV{'--overlap'} });
		push @dad_overlap => grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
			$bk{$dad}->find_range($chr, $start, $end, 
			{ tCover => $ARGV{'--overlap'} });
		my @mom_overlap = grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
			$bk{$mom}->find_range($chr, $start, $end, 
			{ qCover => $ARGV{'--overlap'} });
		push @mom_overlap => grep { $_->[2] eq $cnv && $_->[3] >= $ARGV{'--Q2'} } 
			$bk{$mom}->find_range($chr, $start, $end, 
			{ tCover => $ARGV{'--overlap'} });
		my $flag;
		if (@dad_overlap > 0 && @mom_overlap > 0) {
			$flag = "Inherited";
		}
		elsif (@dad_overlap > 0) {
			$flag = "InheritedFromFather";
		}
		elsif (@mom_overlap > 0) {
			$flag = "InheritedFromMother";
		}
		else {
			$flag = "DeNovo";
		}
		print $finh join("\t",  @{$dat}{@fields}, $flag), "\n";
	}
	else {
		die "Cannot recognize $roles{$iid}[0]";
	}
}



__END__

=head1 REQUIRED ARGUMENTS
 
=over
 
=item -[-]ped [=] <pedfile>

Standard 6-col PED file.

=item -[-]cnv [=] <cnvfile>

CNV input file. CSV format, can be quoted.

*Assumption* if a sample was included in the analysis then it must appear in CNV file!

=item -[-]Q1 [=] <Score>

=item -[-]Q2 [=] <Score>

Quality cutoff for strigent and less stringent CNVs.
Less stringent CNV will be used in testing inheritance or transmission.

=item -[-]output [=] <prefix>

The output file prefix.

=back
 
=head1 OPTIONS
 
=over

=item -[-]maxfreq [=] <freq>

The max. carrier number for CNVs to be considered.
Should be integer, adjusted according to cohort sample size.

=for Euclid:
	freq.default: 13

=item -[-]fields [=] <string>

Fields in CNV file for IID,Chrom,Start,End,CN,Qual.

=for Euclid:
	string.default: "SAMPLE,CHR,START,END,TYPE,Q_SOME"

=item -[-]overlap [=] <perc>

Percentage of length overlap to define the same CNV.
The same percentage will also be used in determine CNV frequency in the cohort.

=for Euclid:
	perc.default: 0.5

=back
